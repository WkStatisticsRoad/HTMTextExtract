package org.numenta.nupic.encoders;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.numenta.nupic.util.MinMax;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class minMaxUnicodeConvertedValueSparseEncoder {

    public static void main(String[] args) {
        String excelFilePath = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\commonChineseCharacterUnicodeConversion.xlsx";
        String sheetName = "Unicode Values";
        String dataFilePath = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\TestText.txt";

        // 读取commonChineseCharacterUnicodeConversion.xlsx表格获取字符与对应的Unicode编码转换值，并存储到Map中
        Map<String, Integer> unicodeMap = readUnicodeMappingFromExcel(excelFilePath, sheetName);

        // 遍历所有文本行，获取最大长度
        int maxLength = getMaxTextLength(dataFilePath);

        double minValue = 1;
        double maxValue = 3596;
        int n = 3746; // SDR的长度,这决定了每个Unicode值被编码后的 SDR
        // 表示有多少个位
        int w = 151;  // 窗口大小长度，表示在该窗口内的输入值将被编码成活跃位，一般取值为奇数
        // 上述四个参数的设置满足 n + minValue = w + maxValue

        /*
         * 参数更新公式
         *  rangeIntel = maxValue - minValue    // rangeIntel表示数据的取值范围（即最大值和最小值之差）
         *  resolution = rangeIntel / (n - w)   // resolution表示每个编码器段的分辨率
         *  radius = w * resolution             // radius表示编码器的半径，即最大有效位的范围，即编码器可以表示的最大差异值
         *  range = rangeIntel + resolution     // range表示编码器的总编码范围
         */

        // 设置适应性标量编码器的参数，包括编码器宽度 w、编码器段数 n、最小值 minValue 和最大值 maxValue
        AdaptiveScalarEncoder encoder = AdaptiveScalarEncoder.adaptiveBuilder()
                .w(w)
                .n(n)
                .minVal(minValue)
                .maxVal(maxValue)
                .build();


        // 读取data.txt文档，并进行Unicode编码转换值的替换
        try (BufferedReader br = new BufferedReader(new FileReader(dataFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                int[] unicodeArrayConversion = convertToUnicodeValue(line, unicodeMap, maxLength, excelFilePath, sheetName);
                System.out.println("输入文本为：" + line);
                System.out.println(Arrays.toString(unicodeArrayConversion));

                int[] encodedArray = adaptiveEncodeArray(unicodeArrayConversion, maxLength, encoder);
                // System.out.println("编码后的结果：" + Arrays.toString(encodedArray));

                int[] decodedArray = adaptiveDecodeArray(encodedArray, maxLength, encoder);
                System.out.println("解码后的结果：" + Arrays.toString(decodedArray));

                // 将解码之后的值转成对应的文本
                String convertedText = convertToCharacter(decodedArray, unicodeMap);
                System.out.println("转换后文本为：" + convertedText);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    // 建立常用汉字、字母和字符等与Unicode编码转换值映射对应关系
    public static Map<String, Integer> readUnicodeMappingFromExcel(String excelFilePath, String sheetName) {
        Map<String, Integer> unicodeMap = new HashMap<>();

        try (FileInputStream file = new FileInputStream(new File(excelFilePath))) {
            Workbook workbook = new XSSFWorkbook(file);
            Sheet sheet = workbook.getSheet(sheetName);  // 获得指定名称的sheetName表的名字

            // 遍历commonChineseCharacterUnicodeConversion.xlsx中常用汉字、字母和字符等与Unicode编码转换值，形成新的对应关系
            for (int i =1;  i <=  sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                String text = row.getCell(0).getStringCellValue();  // 获取对应的字符
                int unicodeValueConversion = (int) row.getCell(1).getNumericCellValue();  // 获取字符对应的Unicode编码转换值
                unicodeMap.put(text, unicodeValueConversion);
            }

            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return unicodeMap;
    }

    // 获取输入文本行对应的最长文本长度
    private static int getMaxTextLength(String dataFilePath) {
        int maxLength = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(dataFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                maxLength = Math.max(maxLength, line.length());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return maxLength;
    }

    // 输出文本对应的Unicode编码转换值
    public static int[] convertToUnicodeValue(String text, Map<String, Integer> unicodeMap, int maxLength, String excelFilePath, String sheetName) {
        int[] unicodeArray = new int[maxLength];
        int offset = maxLength - text.length();  // 根据输入行文本长度与文本最大长度进行匹配，不够的位数用0进行填充
        for (int i = 0; i < maxLength; i++) {
            if (i < offset) {
                unicodeArray[i] = 0;
            } else {
                String singleChar = String.valueOf(text.charAt(i - offset));  // 获取当前位置对应的文本字符，并将其转换为字符串
                if (unicodeMap.containsKey(singleChar)) {  // 判断unicodeMap中是否包含该字符的映射关系
                    unicodeArray[i] = unicodeMap.get(singleChar);  // 如果包含映射关系，则将对应的Unicode编码转换值存赋给对应的字符
                } else {
                    // 如果不包含映射关系，表示该字符在unicodeMap中未找到对应的转换值
                    // 将当前常用字符表中最大Unicode编码转换值加1赋给不在当前文本的字符
                    int maxUnicodeValueConversion = getMaxUnicodeValue(excelFilePath, sheetName);
                    unicodeArray[i] = maxUnicodeValueConversion + 1;  // 获取字符对应的Unicode编码最大转换值
                    System.out.println("未找到映射关系的字符: " + singleChar);
                }
            }
        }
        return unicodeArray;
    }

    // 获取当前常用字符对应最大的Unicode编码转换值
    private static int getMaxUnicodeValue(String excelFilePath, String sheetName) {
        int maxUnicodeValue = Integer.MIN_VALUE;

        try (FileInputStream file = new FileInputStream(new File(excelFilePath))) {
            Workbook workbook = new XSSFWorkbook(file);
            Sheet sheet = workbook.getSheet(sheetName);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                Cell unicodeCell = row.getCell(3);
                int unicodeValueConversion = (int) unicodeCell.getNumericCellValue();
                maxUnicodeValue = Math.max(maxUnicodeValue, unicodeValueConversion);
            }

            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return maxUnicodeValue;
    }

    // 将Unicode编码转换值利用最值稀疏编码的方法进行编码转换
    public static int[] adaptiveEncodeArray(int[] unicodeArrayConversion, int maxLength, AdaptiveScalarEncoder encoder) {


        int[] encodedArray = new int[encoder.getWidth() * maxLength];  // 自适应编码长度为编码器宽度 encoder.getWidth() 乘以最大行长度 maxLength
        int[] encodedSegment1 = new int[encoder.getWidth() * maxLength];   // 存储Unicode码为0进行自适应编码的结果
        int[] encodedSegment2 = new int[encoder.getWidth()];  // 存储Unicode码非0进行自适应编码的结果
        int segment1Index = 0;
        int segment2Index = 0;

        for (int i = 0; i < maxLength; i++) {
            if (unicodeArrayConversion[i] == 0) {
                int[] zeroEncoding = new int[encoder.getWidth()];  // Unicode码为0时，按照编码器的宽度转成对应数量的0

                /*
                 * arrayCopy() 方法用于将源数组 zeroEncoding 的内容复制到目标数组 encodedSegment1 中。具体解释如下：
                 * zeroEncoding：源数组，要进行复制的数组。
                 * encodedSegment1：目标数组，要将源数组内容复制到的数组。
                 * segment1Index：目标数组中的起始索引，表示从该索引位置开始进行复制。
                 * segment2Index：源数组中要复制的起始索引，表示从该索引位置开始复制源数组的内容。
                 * encoder.getWidth()：要复制的元素数量，表示要复制的元素个数。
                 * arrayCopy() 方法会将 zeroEncoding 数组中从 segment2Index 开始的 encoder.getWidth() 个元素复制到 encodedSegment1 数组中，
                 * 从 segment1Index + segment2Index 的位置开始,最后返回更新后的目标数组 encodedSegment1
                 */
                encodedSegment1 = arrayCopy(zeroEncoding, encodedSegment1, segment1Index, segment2Index, encoder.getWidth());
                segment1Index += encoder.getWidth();
            } else {
                encodedSegment2 = encoder.encode((double) unicodeArrayConversion[i]);  // Unicode码不为0时，按照自适应编码的方式进行编码转换
                encodedSegment1 = arrayCopy(encodedSegment2, encodedSegment1, segment1Index, segment2Index, encoder.getWidth());
                segment1Index += encoder.getWidth();
                segment2Index = 0;
            }
        }

        System.arraycopy(encodedSegment1, 0, encodedArray, 0, encodedSegment1.length);
        return encodedArray;
    }

    /*
     * @params src：源数组，要进行复制的数组。
     * @params dest：目标数组，要将源数组内容复制到的数组。
     * @params destStartIndex：目标数组中的起始索引，表示从该索引位置开始进行复制。
     * @params srcStartIndex：源数组中要复制的起始索引，表示从该索引位置开始复制源数组的内容。
     * @params length：要复制的元素数量，表示要复制的元素个数。
     */
    private static int[] arrayCopy(int[] src, int[] dest, int destStartIndex, int srcStartIndex, int length) {
        System.arraycopy(src, 0, dest, destStartIndex + srcStartIndex, length);
        return dest;
    }

    // 将编码之后的向量进行解码
    public static int[] adaptiveDecodeArray(int[] encodedArray, int maxLength, AdaptiveScalarEncoder encoder) {

        int[] decodeArray = new int[maxLength];
        int segmentIndex = 0;

        for (int i = 0; i < maxLength; i++) {
            int[] encodedSegment = Arrays.copyOfRange(encodedArray, segmentIndex, segmentIndex + encoder.getWidth());

            // 判断是否为全0编码,如果为全0编码，则对应的解码值为0；如果不为全0的编码，则调用ScalarEncoder方法中的解码方法进行解码
            boolean isAllZeros = true;
            for (int j = 0; j < encodedSegment.length; j++) {
                if (encodedSegment[j] != 0) {
                    isAllZeros = false;
                    break;
                }
            }

            if (isAllZeros) {
                decodeArray[i] = 0;
            } else {
                DecodeResult decodeResult = encoder.decode(encodedSegment, "fieldName");
                Object decodeRangeValues = decodeResult.getFields().get("fieldName.[1:3596]").get(0);
                ArrayList<MinMax> decodeValuesList = (ArrayList<MinMax>) decodeRangeValues;
                MinMax valueRange = decodeValuesList.get(0);
                int decodeValue = (int)valueRange.min();
                decodeArray[i] = decodeValue;
            }
            segmentIndex += encoder.getWidth();
        }
        return decodeArray;
    }

    // 将Unicode编码转换值转变成对应的文本
    public static String convertToCharacter(int[] unicodeArrayConversion, Map<String, Integer> unicodeMap) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < unicodeArrayConversion.length; i++) {
            for (Map.Entry<String, Integer> entry : unicodeMap.entrySet()) {
                if (entry.getValue() == unicodeArrayConversion[i]) {  // 找到对应的Unicode编码转换值
                    sb.append(entry.getKey());  // 将对应的字符存储到StringBuilder中
                    break;
                }
            }
        }
        return sb.toString();
    }

}
