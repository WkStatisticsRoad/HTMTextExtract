package org.numenta.nupic.examples.paper_data_extract.EncodeMethodTest;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.numenta.nupic.encoders.AdaptiveScalarEncoder;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;

import static org.numenta.nupic.encoders.minMaxUnicodeConvertedValueSparseEncoder.*;


public class CalculateGTRDCosineSimilarity {
    public static void main(String[] args) {
        String filePath = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\EncodeMethodTest\\Geo-Terminology Relatedness Dataset.xlsx";
        String sheetName = "66组结果";

        String excelFilePath = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\commonChineseCharacterUnicodeConversion.xlsx";
        String sheetName1 = "Unicode Values";
        // 读取commonChineseCharacterUnicodeValue.xlsx表格，并存储到Map中
        Map<String, Integer> unicodeMap = readUnicodeMappingFromExcel(excelFilePath, sheetName1);


        int maxLength = 0;  // 初始化最大词长度
        double minValue = 1;
        double maxValue = 3596;
        int n = 3766;        // SDR的长度,这决定了每个Unicode值被编码后的 SDR 表示有多少个位
        int w = 171;


        // 窗口大小长度，表示在该窗口内的输入值将被编码成活跃位，一般取值为奇数
        // 设置适应性标量编码器的参数，包括编码器宽度 w、编码器段数 n、最小值 minValue 和最大值 maxValue
        AdaptiveScalarEncoder encoder = AdaptiveScalarEncoder.adaptiveBuilder()
                .w(w)
                .n(n)
                .minVal(minValue)
                .maxVal(maxValue)
                .build();

        try (FileInputStream file = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(file)) {

            Sheet sheet = workbook.getSheet(sheetName);  // 获得指定名称的sheetName表的名字
            Row headerRow = sheet.getRow(0);  // 获取sheetName表中第一行的标题数据
            int columnIndex = headerRow.getLastCellNum();  // 读取sheetName表中对应的现有数据的列数
            Cell CosineCell = headerRow.createCell(columnIndex);  // 增加一列数据CosineCell
            CosineCell.setCellValue("Cosine Similarity");  // 将CosineCell列的标题命名为Cosine Similarity


            // 创建XYSeries对象来存储Cosine Similarity、Jaccard Index 和基准数据
            XYSeries CosineSeries = new XYSeries("Cosine Similarity");
            XYSeries normalizedSeries = new XYSeries("Normalized Value");

            // 获取sheetName表（验证组）中词三列/词四列对应词的最大长度maxLength
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                String word1 = row.getCell(0).getStringCellValue();
                String word2 = row.getCell(1).getStringCellValue();

                if (word1.length() > maxLength) {
                    maxLength = word1.length();
                }
                if (word2.length() > maxLength) {
                    maxLength = word2.length();
                }
            }

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                String word1 = row.getCell(0).getStringCellValue();  // 获取sheetName表（验证组表）中词三列数据对应的词
                String word2 = row.getCell(1).getStringCellValue();  //  // 获取sheetName表（验证组表）中词四列数据对应的词


                System.out.println("66组基准中文结果分词数据的相似度计算： ");
                int[] unicodeArrayConversion1 = convertToUnicodeValue(word1, unicodeMap, maxLength, excelFilePath, sheetName);
                int[] encodedArray1 = adaptiveEncodeArray(unicodeArrayConversion1, maxLength, encoder);  // 自适应编码AdaptiveScalarEncoder数组


                int[] unicodeArrayConversion2 = convertToUnicodeValue(word2, unicodeMap, maxLength, excelFilePath, sheetName);
                int[] encodedArray2 = adaptiveEncodeArray(unicodeArrayConversion2, maxLength, encoder);  // 自适应编码AdaptiveScalarEncoder数组


                // 计算AdaptiveScalarEncoder编码之后对应的Cosine Similarity
                double CosineSimilarity = calculateCosineSimilarity(encodedArray1, encodedArray2);
                System.out.println("词三列每行词对应的Cosine Similarity： " +CosineSimilarity);
                // 将Cosine Similarity列数据添加到验证组表中
                Cell CosineValueCell = row.createCell(columnIndex);
                CosineValueCell.setCellValue(CosineSimilarity);



                int columnIndexNormalizedValue = 2;  // normalized value值所在列数为第三列
                double normalizedValue = row.getCell(columnIndexNormalizedValue).getNumericCellValue();

                // 将相关系数值和normalized value加入对应的XYSeries对象
                CosineSeries.add(i, CosineSimilarity);
                normalizedSeries.add(i, normalizedValue);
            }

            // 创建XYSeriesCollection对象，将XYSeries对象添加到集合中
            XYSeriesCollection dataset = new XYSeriesCollection();
            dataset.addSeries(CosineSeries);
            dataset.addSeries(normalizedSeries);


            // 保存修改后的Excel文件
            try (FileOutputStream outFile = new FileOutputStream(filePath)) {
                workbook.write(outFile);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // 计算余弦相似度
    public static double calculateCosineSimilarity(int[] array1, int[] array2) {
        double dotProduct = 0.0;
        double norm1 = 0.0;
        double norm2 = 0.0;
        for (int i = 0; i < array1.length; i++) {
            dotProduct += array1[i] * array2[i];
            norm1 += Math.pow(array1[i], 2);
            norm2 += Math.pow(array2[i], 2);
        }
        double similarity = dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
        return similarity;
    }


}
