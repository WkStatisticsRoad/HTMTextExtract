package org.numenta.nupic.examples.paper_data_extract;

import org.numenta.nupic.Parameters;
import org.numenta.nupic.algorithms.BPClassifier;
import org.numenta.nupic.algorithms.SpatialPooler;
import org.numenta.nupic.algorithms.TemporalMemory;
import org.numenta.nupic.encoders.AdaptiveScalarEncoder;
import org.numenta.nupic.model.Cell;
import org.numenta.nupic.model.ComputeCycle;
import org.numenta.nupic.model.Connections;
import org.numenta.nupic.util.ArrayUtils;
import org.numenta.nupic.util.FastRandom;

import java.io.*;
import java.util.*;

import static org.numenta.nupic.encoders.minMaxUnicodeConvertedValueSparseEncoder.*;



public class  TrainDataTitleLerning  {

    static boolean isResetting = true;
    static Map<String, Integer> unicodeMap;
    static String excelFilePath;
    static String sheetName;


    public static void main(String[] args) {


        Parameters parameters = getParameters();

        // 初始化BP分类算法参数
        isResetting = true;
        int inputSize = 30000;
        int hiddenSize = 30000;
        int outputSize = 22476;
        double learningRate = 0.1;


        // 读取PaperDataSetUnicodeConversion.xlsx表格获取字符与对应的Unicode编码转换值，并存储到Map中
        excelFilePath = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\commonChineseCharacterUnicodeConversion.xlsx";
        sheetName = "Unicode Values";
        unicodeMap = readUnicodeMappingFromExcel(excelFilePath, sheetName);


        double minValue = 1;
        double maxValue = 3596;
        int n = 3746; // SDR的长度,这决定了每个Unicode值被编码后的 SDR 表示有多少个位
        int w = 151;  // 窗口大小长度，表示在该窗口内的输入值将被编码成活跃位，一般取值为奇数



        // 设置适应性标量编码器的参数，包括编码器宽度 w、编码器段数 n、最小值 minValue 和最大值 maxValue
        AdaptiveScalarEncoder encoder = AdaptiveScalarEncoder.adaptiveBuilder()
                .w(w)
                .n(n)
                .minVal(minValue)
                .maxVal(maxValue)
                .build();


        SpatialPooler spatialPooler = new SpatialPooler();
        TemporalMemory temporalMemory = new TemporalMemory();
        BPClassifier classifier = new BPClassifier(inputSize, hiddenSize, outputSize, learningRate);
        Layer<int[]> layer = getLayer(parameters, encoder, spatialPooler, temporalMemory, classifier);

        String datafilePath = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\trainDataSetTitles.txt";
        int lineCount = countLines(datafilePath);  // onedata.txt中的数据总行数

        for(int i = 0, j = 0 ; i < 100 ; i++, j += lineCount) {

            if (j== 0 && isResetting) {
                System.out.println("reset:");
                temporalMemory.reset(layer.getMemory());
            }


            runThroughLayer(layer,(int)i, (int)j);
        }



    }



    public static Parameters getParameters() {
        Parameters parameters = Parameters.getAllDefaultParameters();
        parameters.set(Parameters.KEY.CELLS_PER_COLUMN, 6);
        //SpatialPooler specific
        parameters.set(Parameters.KEY.INPUT_DIMENSIONS, new int[]{22476});
        parameters.set(Parameters.KEY.COLUMN_DIMENSIONS, new int[]{5000});
        parameters.set(Parameters.KEY.POTENTIAL_RADIUS, new int[]{6});
        parameters.set(Parameters.KEY.POTENTIAL_PCT, 1.0);
        parameters.set(Parameters.KEY.GLOBAL_INHIBITION, true);
        parameters.set(Parameters.KEY.LOCAL_AREA_DENSITY, -1.0);
        parameters.set(Parameters.KEY.NUM_ACTIVE_COLUMNS_PER_INH_AREA, 48.0);
        parameters.set(Parameters.KEY.STIMULUS_THRESHOLD, 3.0);
        parameters.set(Parameters.KEY.SYN_PERM_INACTIVE_DEC, 0.0005);
        parameters.set(Parameters.KEY.SYN_PERM_ACTIVE_INC, 0.0015);
        parameters.set(Parameters.KEY.SYN_PERM_TRIM_THRESHOLD, 0.05);
        parameters.set(Parameters.KEY.SYN_PERM_CONNECTED, 0.1);
        parameters.set(Parameters.KEY.MIN_PCT_OVERLAP_DUTY_CYCLES, 0.1);
        parameters.set(Parameters.KEY.MIN_PCT_ACTIVE_DUTY_CYCLES, 0.1);
        parameters.set(Parameters.KEY.DUTY_CYCLE_PERIOD, 10);
        parameters.set(Parameters.KEY.MAX_BOOST, 10.0);
        parameters.set(Parameters.KEY.SEED, 42);
        parameters.set(Parameters.KEY.INITIAL_PERMANENCE, 0.1);  // 0.2 初始持久度
        parameters.set(Parameters.KEY.CONNECTED_PERMANENCE, 0.7);  // 连接持久度阈值

        //Temporal Memory specific
        parameters.set(Parameters.KEY.MIN_THRESHOLD, 4);
        parameters.set(Parameters.KEY.MAX_NEW_SYNAPSE_COUNT, 6);
        parameters.set(Parameters.KEY.PERMANENCE_INCREMENT, 0.1);
        parameters.set(Parameters.KEY.PERMANENCE_DECREMENT, 0.1);
        parameters.set(Parameters.KEY.ACTIVATION_THRESHOLD, 4);
        parameters.set(Parameters.KEY.LEARNING_RADIUS, 20);

        parameters.set(Parameters.KEY.RANDOM, new FastRandom());

        // Increase the number of active columns per inhibition area
        parameters.set(Parameters.KEY.NUM_ACTIVE_COLUMNS_PER_INH_AREA, 100.0);

        // Increase the number of training iterations
        parameters.set(Parameters.KEY.DUTY_CYCLE_PERIOD, 100);

        return parameters;
    }


    // 读取训练数据集中的数据总行数
    public static int countLines(String filePath) {
        int count = 0;
        try {
            File file = new File(filePath);
            Scanner scanner = new Scanner(file);


            while (scanner.hasNextLine()) {
                scanner.nextLine();
                count++;
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return count;
    }

    public static void runThroughLayer(Layer<int[]> layer, int recordNum, int sequenceNum) {
        layer.input(recordNum, sequenceNum);
    }


    public static Layer<int[]> getLayer(Parameters p, AdaptiveScalarEncoder e, SpatialPooler s, TemporalMemory t, BPClassifier c) {
        Layer<int[]> layer = new LayerImpl(p, e, s, t, c);
        return layer;
    }

    public interface Layer<T> {
        void input(int recordNum, int sequenceNum);
        int[] getPredicted();
        Connections getMemory();
        int[] getActual();
    }

    public static class LayerImpl implements Layer<int[]> {
        private Parameters params;
        private Connections memory = new Connections();
        private AdaptiveScalarEncoder encoder;
        private SpatialPooler spatialPooler;
        private TemporalMemory temporalMemory;
        private BPClassifier classifier;
        private int columnCount;
        private int cellsPerColumn;


        private int theNum;//标记迭代轮数
        private int[] actual;
        private int[] predictedColumns;
        private int[] lastPredicted;

        public LayerImpl(Parameters p, AdaptiveScalarEncoder e, SpatialPooler s, TemporalMemory t, BPClassifier c) {
            this.params = p;
            this.encoder = e;
            this.spatialPooler = s;
            this.temporalMemory = t;
            this.classifier = c;
            params.apply(memory);
            spatialPooler.init(memory);
            TemporalMemory.init(memory);

            columnCount = memory.getPotentialPools().getMaxIndex() + 1;
            cellsPerColumn = memory.getCellsPerColumn();
        }

        public void input(int recordNum, int sequenceNum) {


            System.out.println("--------------------------------------------------------");
            theNum++;
            System.out.println("循环迭代轮数--Iteration: " + theNum);


            String datafilePath = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\trainDataSetTitles.txt";
            List<String> lines = new ArrayList<>();
            int maxLength = 0;

            try (BufferedReader br = new BufferedReader(new FileReader(datafilePath))) {
                String line;
                while ((line = br.readLine()) != null) {
                    lines.add(line);
                    if (line.length() > maxLength) {
                        maxLength = line.length();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            for (String line : lines) {
                System.out.println("-------------------------");
                System.out.println("输入的文本内容：");
                System.out.println(line);

                // 根据输入的最大文本长度转换Unicode编码值，不足的位数用0补齐
                int[] unicodeArrayConversion = convertToUnicodeValue(line, unicodeMap, maxLength, excelFilePath, sheetName);
                System.out.println("Unicode编码转换值的结果：" + Arrays.toString(unicodeArrayConversion));

                // 将Unicode编码值进行稀疏编码转换
                int[] encodedArray = adaptiveEncodeArray(unicodeArrayConversion, maxLength, encoder);
                // System.out.println("编码后的结果：" + Arrays.toString(encodedArray));


                //Input through spatial pooler
                int[] output1 = new int[columnCount];
                spatialPooler.compute(memory, encodedArray, output1, true);
                System.out.println("SpatialPooler Output1 = " + Arrays.toString(output1));
                // Let the SpatialPooler train independently (warm up) first，首先让SpatialPooler单独训练（预热），迭代几十轮之后再去训练TemporalMemory

                sequenceNum++;
            }

            if (theNum == 100) {


                String filePath1 = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\ScienceDataTitleExtractResult.txt";

                try {

                    PrintWriter writer = new PrintWriter(new FileWriter(filePath1, true)); // 第二个参数为true表示追加写入


                    String filePath2 = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\trainDataSetTitles.txt";
                    String filePath3 = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\TestText.txt";
                    List<String> lines2 = new ArrayList<>();
                    List<String> lines3 = new ArrayList<>();
                    int maxLength2 = 0;
                    int maxLength3 = 0;
                    int sequenceNum1 = 0;


                    try (BufferedReader br = new BufferedReader(new FileReader(filePath2))) {
                        String line2;
                        while ((line2 = br.readLine()) != null) {
                            lines2.add(line2);
                            if (line2.length() > maxLength2) {
                                maxLength2 = line2.length();
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    try (BufferedReader br1 = new BufferedReader(new FileReader(filePath3))) {
                        String line3;
                        while ((line3 = br1.readLine()) != null) {
                            lines3.add(line3);
                            if (line3.length() > maxLength3) {
                                maxLength3 = line3.length();
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    for(int itertimes = 0; itertimes < 101; itertimes++){

                        for (int i =0; i < lines2.size(); i++) {
                            String line2 = lines2.get(i);
                            System.out.println("-------------------------");
                            System.out.println("输入的文本内容：");
                            writer.println("输入的文本内容：" + line2);
                            System.out.println(line2);


                            // 根据输入的最大文本长度转换Unicode编码，不足的位数用0补齐
                            int[] unicodeArrayConversion2 = convertToUnicodeValue(line2, unicodeMap, maxLength, excelFilePath, sheetName);
                            System.out.println("Unicode编码转换值的结果：" + Arrays.toString(unicodeArrayConversion2));

                            // 将Unicode编码值进行稀疏编码转换
                            int[] encodedArray2 = adaptiveEncodeArray(unicodeArrayConversion2, maxLength, encoder);
                            // System.out.println("编码后的结果：" + Arrays.toString(encodedArray2));


                            //Input through spatial pooler
                            int[] output2 = new int[columnCount];
                            spatialPooler.compute(memory, encodedArray2, output2, true);
                            System.out.println("SpatialPooler Output1 = " + Arrays.toString(output2));

                            //Input through temporal memory
                            int[] input_predict1 = actual = ArrayUtils.where(output2, ArrayUtils.WHERE_1);
                            ComputeCycle cc_easy1 = temporalMemory.compute(memory, input_predict1, true);
                            lastPredicted = predictedColumns;
                            predictedColumns = getSDR(cc_easy1.predictiveCells());
                            //Get the active cells for classifier input
                            int[] activeCellIndexes_easy1 = Connections.asCellIndexes(cc_easy1.activeCells()).stream().mapToInt(p -> p).sorted().toArray();
                            System.out.println("TemporalMemory InputPredict = " + Arrays.toString(input_predict1));
                            System.out.println("TM过程激活的细胞索引：" + Arrays.toString(activeCellIndexes_easy1));


                            // 将激活位置的索引转成1，其余为0
                            StringBuilder binaryVector = new StringBuilder();
                            for (int j = 0; j < 30000; j++) {
                                if (Arrays.binarySearch(activeCellIndexes_easy1, j) >= 0) {

                                    binaryVector.append("1");
                                } else {
                                    binaryVector.append("0");
                                }
                            }

                            double[] activeBinaryArray = new double[binaryVector.length()];
                            for (int l = 0; l < binaryVector.length(); l++) {
                                activeBinaryArray[l] = Double.parseDouble(String.valueOf(binaryVector.charAt(l)));
                            }
                            // System.out.println("activeCellIndexes_easy1对应的二进制向量："+Arrays.toString(activeBinaryArray));



                            int nextLineIndex = i + 1;
                            if (nextLineIndex < lines2.size()) {
                                String nextLine = lines2.get(nextLineIndex);
                                int[] nextUnicodeArrayConversion = convertToUnicodeValue(nextLine, unicodeMap, maxLength, excelFilePath, sheetName);
                                int[] nextEncodedArray = adaptiveEncodeArray(nextUnicodeArrayConversion , maxLength2, encoder);

                                // 使用BP分类器进行训练和预测
                                boolean learn = true; // 设置为true表示进行训练
                                boolean infer = true; // 设置为true表示进行推断
                                int[] predictedOutput = classifier.compute(sequenceNum1, activeBinaryArray, nextEncodedArray, learn, infer);
                                // System.out.println("BPClassification result: " + Arrays.toString(predictedOutput));
                                int[] decodedArray = adaptiveDecodeArray(predictedOutput, maxLength, encoder);
                                String predictedOutputText = convertToCharacter(decodedArray, unicodeMap);
                                System.out.println("预测向量的对应的解码文本为：" + predictedOutputText);
                                writer.println("预测向量的对应的解码文本为：" + predictedOutputText);
                                sequenceNum1 += 1;

                            }
                        }

                        if(itertimes == 100){

                            StringBuilder resultBuilder = new StringBuilder();
                            List<String> PredictTextList = new ArrayList<>();
                            for (int i =0; i < lines3.size(); i++) {
                                String line3 = lines3.get(i);
                                System.out.println("-------------------------");
                                System.out.println("输入的文本内容：");
                                writer.println("输入的文本内容：" + line3);
                                System.out.println(line3);


                                // 根据输入的最大文本长度转换Unicode编码，不足的位数用0补齐
                                int[] unicodeArrayConversion3 = convertToUnicodeValue(line3, unicodeMap, maxLength, excelFilePath, sheetName);
                                System.out.println("Unicode编码转换值的结果：" + Arrays.toString(unicodeArrayConversion3));

                                // 将Unicode编码值进行稀疏编码转换
                                int[] encodedArray3 = adaptiveEncodeArray(unicodeArrayConversion3, maxLength3, encoder);
                                // System.out.println("编码后的结果：" + Arrays.toString(encodedArray3));


                                //Input through spatial pooler
                                int[] output3 = new int[columnCount];
                                spatialPooler.compute(memory, encodedArray3, output3, false);
                                System.out.println("SpatialPooler Output1 = " + Arrays.toString(output3));

                                //Input through temporal memory
                                int[] input_predict1 = actual = ArrayUtils.where(output3, ArrayUtils.WHERE_1);
                                ComputeCycle cc_easy1 = temporalMemory.compute(memory, input_predict1, false);
                                lastPredicted = predictedColumns;
                                predictedColumns = getSDR(cc_easy1.predictiveCells());
                                //Get the active cells for classifier input
                                int[] activeCellIndexes_easy1 = Connections.asCellIndexes(cc_easy1.activeCells()).stream().mapToInt(p -> p).sorted().toArray();
                                System.out.println("TemporalMemory InputPredict = " + Arrays.toString(input_predict1));
                                System.out.println("TM过程激活的细胞索引：" + Arrays.toString(activeCellIndexes_easy1));

                                // 将激活位置的索引转成1，其余为0
                                StringBuilder binaryVector = new StringBuilder();
                                for (int j = 0; j < 30000; j++) {
                                    if (Arrays.binarySearch(activeCellIndexes_easy1, j) >= 0) {

                                        binaryVector.append("1");
                                    } else {
                                        binaryVector.append("0");

                                    }
                                }

                                double[] activeBinaryArray = new double[binaryVector.length()];
                                for (int l = 0; l < binaryVector.length(); l++) {
                                    activeBinaryArray[l] = Double.parseDouble(String.valueOf(binaryVector.charAt(l)));
                                }
                                // System.out.println("activeCellIndexes_easy1对应的二进制向量："+Arrays.toString(activeBinaryArray));



                                int nextLineIndex = i + 1;
                                if (nextLineIndex < lines3.size()) {
                                    String nextLine = lines3.get(nextLineIndex);
                                    int[] nextUnicodeArrayConversion1 = convertToUnicodeValue(nextLine, unicodeMap, maxLength, excelFilePath, sheetName);
                                    int[] nextEncodedArray1 = adaptiveEncodeArray(nextUnicodeArrayConversion1, maxLength3, encoder);


                                    // 使用BP分类器进行训练和预测
                                    boolean learn = false; // 设置为true表示进行训练
                                    boolean infer = true; // 设置为true表示进行推理
                                    int[] predictedOutput = classifier.compute(sequenceNum1, activeBinaryArray, nextEncodedArray1, learn, infer);
                                    double similarity = cosineSimilarity(predictedOutput, nextEncodedArray1);
                                    System.out.println("预测向量和下一期向量相似度为：" + similarity);
                                    writer.println("预测向量和下一期向量相似度为：" + similarity);
                                    if (similarity > 0.4) {
                                        System.out.println("相似度值大于0.4的值进行输出：" + similarity);
                                        writer.println("相似度值大于0.4的值进行输出：" + similarity);
                                        // System.out.println("预测向量为: " + Arrays.toString(predictedOutput));
                                        int[] decodedArray = adaptiveDecodeArray(nextEncodedArray1, maxLength, encoder);
                                        System.out.println("解码后的结果：" + Arrays.toString(decodedArray));
                                        String PredictText = convertToCharacter(decodedArray, unicodeMap);
                                        System.out.println("解码后的值转换成文本结果：" + PredictText);
                                        writer.println("解码后的值转换成文本结果: " + PredictText);
                                        PredictTextList.add(PredictText);
                                    } else {
                                        System.out.println("相似度值为："+similarity);
                                    }
                                    sequenceNum1 += 1;

                                }
                            }




                            for (String text : PredictTextList) {
                                System.out.println(text);
                                resultBuilder.append(text);  // 将PredictText追加到结果字符串中
                            }

                            String result = resultBuilder.toString();
                            System.out.println("提取的数据集名称结果为: " + result);

                        }
                    }


                } catch(IOException e){
                    throw new RuntimeException(e);
                }


            }

        }

        public int[] getPredicted() {
            return lastPredicted;
        }

        public Connections getMemory() {
            return memory;
        }

        public int[] getActual() {
            return actual;
        }

        public int[] getSDR(Set<Cell> cells) {
            int[] retVal = new int[cells.size()];
            int i = 0;
            for (Cell cell : cells) {
                retVal[i] = cell.getIndex() / cellsPerColumn;
                i++;
            }
            Arrays.sort(retVal);
            retVal = ArrayUtils.unique(retVal);

            return retVal;
        }

        // 计算向量之间的相似度
        public static double cosineSimilarity(int[] vector1, int[] vector2) {
            double dotProduct = 0;
            double norm1 = 0;
            double norm2 = 0;
            for (int i = 0; i < vector1.length; i++) {
                dotProduct += vector1[i] * vector2[i];
                norm1 += Math.pow(vector1[i], 2);
                norm2 += Math.pow(vector2[i], 2);
            }
            double similarity = dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
            return similarity;
        }

    }
}













