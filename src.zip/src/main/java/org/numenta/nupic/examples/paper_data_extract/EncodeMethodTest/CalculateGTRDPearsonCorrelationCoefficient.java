package org.numenta.nupic.examples.paper_data_extract.EncodeMethodTest;


import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.distribution.TDistribution;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;



public class CalculateGTRDPearsonCorrelationCoefficient {
    public static void main(String[] args) {
        String filePath = "G:\\java\\Projects\\HTMTextExtract\\src\\main\\java\\org\\numenta\\nupic\\examples\\paper_data_extract\\EncodeMethodTest\\Geo-Terminology Relatedness Dataset.xlsx";
        String sheetName = "66组结果";

        try (FileInputStream file = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(file)) {

            Sheet sheet = workbook.getSheet(sheetName);
            int rowCount = sheet.getLastRowNum();
            double[] column1 = new double[rowCount];
            double[] column2 = new double[rowCount];
            double[] column3 = new double[rowCount];


            // 获取 normalized value/semantic folding和 Cosine Similarity
            for (int i = 1; i <= rowCount; i++) {
                Row row = sheet.getRow(i);
                Cell cell1 = row.getCell(2);
                Cell cell2 = row.getCell(3);
                Cell cell3 = row.getCell(4);


                column1[i - 1] = cell1.getNumericCellValue();  // 获取normalized value
                column2[i - 1] = cell2.getNumericCellValue();  // 获取semantic folding
                column3[i - 1] = cell3.getNumericCellValue();  // 获取AdaptiveScalarEncoder编码计算得到的Cosine Similarity

            }

            // 计算Pearson相关系数值
            PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation();
            double pearsonCorrelation12 = pearsonsCorrelation.correlation(column1, column2);
            double pearsonCorrelation13 = pearsonsCorrelation.correlation(column1, column3);
            System.out.println("normalized value与semantic folding编码计算得到的overlap的Pearson相关系数: " + pearsonCorrelation12);
            System.out.println("normalized value与AdaptiveScalarEncoder编码计算得到的Cosine Similarity的Pearson相关系数: " + pearsonCorrelation13);



            // 计算Pearson相关系数的p值
            int degreesOfFreedom = rowCount - 2; // 自由度
            TDistribution tDistribution = new TDistribution(degreesOfFreedom);

            // Pearson相关系数的p值
            // Pearson相关系数检验统计量 t = r * sqrt((n-2)/(1-r^2))
            // Pearson相关系数的双侧检验 p值 = 2*(1-T(t)),  T(t)为T分布累积概率值
            double pearsonPValue12 = getPearsonPValue(pearsonCorrelation12, tDistribution);
            double pearsonPValue13 = getPearsonPValue(pearsonCorrelation13, tDistribution);
            System.out.println("normalized value与semantic folding编码计算得到的overlap的Pearson相关系数的p值: " + pearsonPValue12);
            System.out.println("normalized value与AdaptiveScalarEncoder编码计算得到的Cosine Similarity的Pearson相关系数的p值: " + pearsonPValue13);



            // Pearson/Spearman相关系数检验（t = r * sqrt((n-2)/(1-r^2))）
            // 进行相关系数检验
            double significanceLevel = 0.05;

            if (isSignificant(pearsonCorrelation12, rowCount, significanceLevel)) {
                System.out.println("normalized value与semantic folding编码计算得到的overlap的Pearson相关系数是显著的");
            } else {
                System.out.println("normalized value与AdaptiveScalarEncoder编码计算得到的Cosine Similarity的Pearson相关系数是不显著的");
            }
            if (isSignificant(pearsonCorrelation13, rowCount, significanceLevel)) {
                System.out.println("normalized value与AdaptiveScalarEncoder编码计算得到的Cosine Similarity的Pearson相关系数是显著的");
            } else {
                System.out.println("normalized value与AdaptiveScalarEncoder编码计算得到的Cosine Similarity的Pearson相关系数是不显著的");
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 检验相关系数是否显著
    private static boolean isSignificant(double correlation, int sampleSize, double significanceLevel) {
        double degreesOfFreedom = sampleSize - 2; // 自由度
        double testStatistic = correlation * Math.sqrt(degreesOfFreedom / (1 - correlation * correlation));

        TDistribution tDistribution = new TDistribution(degreesOfFreedom);
        double criticalValue = tDistribution.inverseCumulativeProbability(1 - significanceLevel / 2); // 双尾检验

        return Math.abs(testStatistic) > criticalValue;
    }


    // 计算Pearson相关系数对应的p值
    private static double getPearsonPValue(double correlation, TDistribution tDistribution) {
        double t = correlation * Math.sqrt((tDistribution.getDegreesOfFreedom() - 2) / (1 - correlation * correlation));
        return 2 * (1 - tDistribution.cumulativeProbability(Math.abs(t)));
    }

    // 计算Spearman相关系数对应的p值
    private static double getSpearmanPValue(double correlation, int sampleSize) {
        double testStatistic = correlation * Math.sqrt(sampleSize - 1);
        NormalDistribution normalDistribution = new NormalDistribution(0, 1);
        return 2 * (1 - normalDistribution.cumulativeProbability(Math.abs(testStatistic)));
    }
}
