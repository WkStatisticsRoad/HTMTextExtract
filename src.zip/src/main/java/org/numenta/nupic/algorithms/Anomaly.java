/* ---------------------------------------------------------------------
 * Numenta Platform for Intelligent Computing (NuPIC)
 * Copyright (C) 2014, Numenta, Inc.  Unless you have an agreement
 * with Numenta, Inc., for a separate license for this software code, the
 * following terms and conditions apply:
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero Public License version 3 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Affero Public License for more details.
 *
 * You should have received a copy of the GNU Affero Public License
 * along with this program.  If not, see http://www.gnu.org/licenses.
 *
 * http://numenta.org/licenses/
 * ---------------------------------------------------------------------
 */

package org.numenta.nupic.algorithms;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.numenta.nupic.model.Persistable;
import org.numenta.nupic.util.ArrayUtils;

import gnu.trove.list.TDoubleList;
import gnu.trove.list.array.TDoubleArrayList;


/*
 * This module analyzes and estimates the distribution of averaged anomaly scores
 * from a CLA model. Given a new anomaly score `s`, estimates `P(score >= s)`.
 *
 * The number `P(score >= s)` represents the likelihood of the current state of
 * predictability. For example, a likelihood of 0.01 or 1% means we see this much
 * predictability about one out of every 100 records. The number is not as unusual
 * as it seems. For records that arrive every minute, this means once every hour
 * and 40 minutes. A likelihood of 0.0001 or 0.01% means we see it once out of
 * 10,000 records, or about once every 7 days.
 *本模块分析和估计来自CLA模型的平均异常分数的分布。给定一个新的异常分数“s”，
 *它可以估计“P（score >= s）”的概率。这个数字表示当前预测可靠性的可能性。
 * 例如，概率为0.01或1％意味着我们在每100个记录中看到这么多的可预测性。
 * 这个数字并不像它看起来那么不寻常。对于每分钟到达的记录，这意味着每小时和40分钟一次。
 * 概率为0.0001或0.01％意味着我们在10000个记录中看到一次，或者大约每7天一次。
 *
 *
 * USAGE
 * -----
 *
 * The {@code Anomaly} base class follows the factory pattern and can construct an
 * appropriately configured anomaly calculator by invoking the following:
 * 
 * <pre>
 * Map<String, Object> params = new HashMap<>();
 * params.put(KEY_MODE, Mode.LIKELIHOOD);            // May be Mode.PURE or Mode.WEIGHTED
 * params.put(KEY_USE_MOVING_AVG, true);             // Instructs the Anomaly class to compute moving average
 * params.put(KEY_WINDOW_SIZE, 10);                  // #of inputs over which to compute the moving average
 * params.put(KEY_IS_WEIGHTED, true);                // Use a weighted moving average or not
 * 
 * // Instantiate the Anomaly computer
 * Anomaly anomalyComputer = Anomaly.create(params); // Returns the appropriate Anomaly
 *                                                   // implementation.
 * int[] actual = array of input columns at time t
 * int[] predicted = array of predicted columns for t+1
 * double anomaly = an.compute(
 *     actual, 
 *     predicted, 
 *     0 (inputValue = OPTIONAL, needed for likelihood calcs), 
 *     timestamp);
 *     
 * double anomalyProbability = anomalyComputer.anomalyProbability(
 *     inputValue, anomaly, timestamp);
 * </pre>
 *
 * Raw functions
 * -------------
 * 
 * There are two lower level functions, estimateAnomalyLikelihoods and
 * updateAnomalyLikelihoods. The details of these are described by the method docs.
 * 
 * For more information please see: {@link AnomalyTest} and {@link AnomalyLikelihoodTest}
 * 
 * @author Numenta
 * @author David Ray
 * @see AnomalyTest
 * @see AnomalyLikelihoodTest
 */
public abstract class Anomaly implements Persistable {

    /*
    *public static final：表示定义一个公共的静态不可变常量，该常量在整个程序中都可被访问，并且只能被赋值一次。
    *public final static：与 public static final 作用类似，这种写法也是定义一个公共的静态不可变常量。
    *protected：表示定义的成员变量或方法在本类和其子类中可访问，但在其他类中不可访问。
    *protected boolean：表示定义一个保护级别的 boolean 类型成员变量，可以被本类和其子类访问。
    *所以，区别在于：
    *其中，public static final和public final static以不同的顺序声明常量，但无实际差异。
    *protected和protected boolean都表示可被本类和其子类访问，但前者用于声明成员变量或方法，后者则用于声明保护级别的 boolean 类型成员变量。
    */
    
    private static final long serialVersionUID = 1L;  //表示定义了一个私有的静态不可变常量，用于提供可序列化的类版本号。该常量被Java的序列化机制使用，用于验证序列化对象与相应类是否兼容。

    /** Modes to use for factory creation method */
    public enum Mode { PURE, LIKELIHOOD, WEIGHTED };  //定义了一个名为Mode的枚举类型。枚举是Java语言中一种特殊的类，其中的每个值都是一个常量，可以在程序中使用。
    
    // Instantiation keys
    public static final int VALUE_NONE = -1;  //定义了一个公共的静态不可变常量，表示无效值。变量VALUE_NONE被声明为int类型，且只能被赋值一次。
    public static final String KEY_MODE = "mode".intern();  //定义了一个名为KEY_MODE的字符串常量。该字符串常量被声明为公共的静态不可变常量，并在常量池中只存储一份实例。使用String.intern()方法来确保它在常量池中只存在一份。
    public static final String KEY_LEARNING_PERIOD = "claLearningPeriod";   //定义了一个公共的静态不可变字符串常量，表示学习周期。该常量被用于配置。


    public static final String KEY_ESTIMATION_SAMPLES = "estimationSamples";  //定义了一个公共的静态不可变字符串常量，表示估计样本。该常量被用于配置。
    public static final String KEY_USE_MOVING_AVG = "useMovingAverage";  //定义了一个公共的静态不可变字符串常量，表示是否使用移动平均数。该常量被用于配置。
    public static final String KEY_WINDOW_SIZE = "windowSize".intern();  //定义了一个公共的静态不可变字符串常量，表示窗口大小。该常量被用于配置。
    public static final String KEY_IS_WEIGHTED = "isWeighted";   //定义了一个公共的静态不可变字符串常量，表示是否按权重计算。该常量被用于配置
    // Configs
    public static final String KEY_DIST = "distribution".intern();  //定义了一个公共的静态不可变字符串常量，表示分布。该常量被用于配置
    public static final String KEY_MVG_AVG = "movingAverage".intern();  //定义了一个公共的静态不可变字符串常量，表示移动平均数。该常量被用于配置。
    public static final String KEY_HIST_LIKE = "historicalLikelihoods".intern();  //定义了一个公共的静态不可变字符串常量，表示历史概率。该常量被用于配置。
    public static final String KEY_HIST_VALUES = "historicalValues".intern();  //定义了一个公共的静态不可变字符串常量，表示历史值。该常量被用于配置
    public static final String KEY_TOTAL = "total".intern();  //定义了一个公共的静态不可变字符串常量，表示总数。该常量被用于配置。
    
    // Computational argument keys
    public final static String KEY_MEAN = "mean".intern();  //定义了一个公共的静态不可变字符串常量，表示总数。该常量被用于配置。
    public final static String KEY_STDEV = "stdev".intern();
    public final static String KEY_VARIANCE = "variance".intern();
    
    protected MovingAverage movingAverage;  //定义了一个保护级别的MovingAverage类型的变量movingAverage，表示移动平均数。
    
    protected boolean useMovingAverage;  //定义了一个保护级别的布尔类型成员变量useMovingAverage，表示是否使用移动平均数。
    
    /**
     * Constructs a new {@code Anomaly}
     */
    public Anomaly() {
        this(false, -1);
    }
    
    /**
     * Constructs a new {@code Anomaly}
     * 
     * @param useMovingAverage  indicates whether to apply and store a moving average
     * @param windowSize        size of window to average over
     */
    protected Anomaly(boolean useMovingAverage, int windowSize) {
        this.useMovingAverage = useMovingAverage;
        if(this.useMovingAverage) {
            if(windowSize < 1) {
                throw new IllegalArgumentException(
                    "Window size must be > 0, when using moving average.");
            }
            movingAverage = new MovingAverage(null, windowSize);
        }
    }
    
    /**
     * Convenience method to create a simplistic Anomaly computer in 
     * {@link Mode#PURE}
     *  
     * @return
     */
    public static Anomaly create() {
        Map<String, Object> params = new HashMap<>();
        params.put(KEY_MODE, Mode.PURE);
        
        return create(params);
    }
    
    /*
     * Returns an {@code Anomaly} configured to execute the type
     * of calculation specified by the {@link Mode}, and whether or
     * not to apply a moving average.
     * 
     * Must have one of "MODE" = {@link Mode#LIKELIHOOD}, {@link Mode#PURE}, {@link Mode#WEIGHTED}
     * 
     * @param   p       Map 
     * @return
     */
    public static Anomaly create(Map<String, Object> params) {
        boolean useMovingAvg = (boolean)params.getOrDefault(KEY_USE_MOVING_AVG, false);
        int windowSize = (int)params.getOrDefault(KEY_WINDOW_SIZE, -1);
        if(useMovingAvg && windowSize < 1) {
            throw new IllegalArgumentException("windowSize must be > 0, when using moving average.");
        }
        
        Mode mode = (Mode)params.get(KEY_MODE);
        if(mode == null) {
            throw new IllegalArgumentException("MODE cannot be null.");
        }
        
        switch(mode) {
            case PURE: return new Anomaly(useMovingAvg, windowSize) {
                private static final long serialVersionUID = 1L;

                @Override
                public double compute(int[] activeColumns, int[] predictedColumns, double inputValue, long timestamp) {
                    double retVal = computeRawAnomalyScore(activeColumns, predictedColumns);
                    if(this.useMovingAverage) {
                        retVal = movingAverage.next(retVal);
                    }
                    return retVal;
                }
            };
            case LIKELIHOOD: 
            case WEIGHTED: {
                boolean isWeighted = (boolean)params.getOrDefault(KEY_IS_WEIGHTED, false);
                int claLearningPeriod = (int)params.getOrDefault(KEY_LEARNING_PERIOD, VALUE_NONE);
                int estimationSamples = (int)params.getOrDefault(KEY_ESTIMATION_SAMPLES, VALUE_NONE);
               
                return new AnomalyLikelihood(useMovingAvg, windowSize, isWeighted, claLearningPeriod, estimationSamples);
            }
            default: return null;
        }
    }
    
    /**
     * The raw anomaly score is the fraction of active columns not predicted.
     * 
     * @param   activeColumns           an array of active column indices
     * @param   prevPredictedColumns    array of column indices predicted in the 
     *                                  previous step
     * @return  anomaly score 0..1 
     */
    public static double computeRawAnomalyScore(int[] activeColumns, int[] prevPredictedColumns) {
        double score = 0;
        
        int nActiveColumns = activeColumns.length;
        if(nActiveColumns > 0) {
            // Test whether each element of a 1-D array is also present in a second
            // array. Sum to get the total # of columns that are active and were
            // predicted.
            score = ArrayUtils.in1d(activeColumns, prevPredictedColumns).length;
            // Get the percent of active columns that were NOT predicted, that is
            // our anomaly score.
            score = (nActiveColumns - score) / (double)nActiveColumns;
        } else {
            score = 0.0d;
        }
        
        return score;
    }
    
    /**
     * Compute the anomaly score as the percent of active columns not predicted.
     * 
     * @param activeColumns         array of active column indices
     * @param predictedColumns      array of columns indices predicted in this step
     *                              (used for anomaly in step T+1)
     * @param inputValue            (optional) value of current input to encoders 
     *                              (eg "cat" for category encoder)
     *                              (used in anomaly-likelihood)
     * @param timestamp             timestamp: (optional) date timestamp when the sample occurred
     *                              (used in anomaly-likelihood)
     * @return
     */
    public abstract double compute(int[] activeColumns, int[] predictedColumns, double inputValue, long timestamp);
    
    
    //////////////////////////////////////////////////////////////////////////////////////
    //                            Inner Class Definitions                               //
    //////////////////////////////////////////////////////////////////////////////////////
    /**
     * Container to hold interim {@link AnomalyLikelihood} calculations.
     * 
     * @author David Ray
     * @see AnomalyLikelihood
     * @see MovingAverage
     */
    public class AveragedAnomalyRecordList implements Persistable {
        private static final long serialVersionUID = 1L;
        
        public List<Sample> averagedRecords;
        public TDoubleList historicalValues;
        public double total;
        
        /**
         * Constructs a new {@code AveragedAnomalyRecordList}
         * 
         * @param averagedRecords       List of samples which are { timestamp, average, value } at a data point
         * @param historicalValues      List of values of a given window size (moving average grouping)
         * @param total                 Sum of all values in the series
         */
        public AveragedAnomalyRecordList(List<Sample> averagedRecords, TDoubleList historicalValues, double total) {
            this.averagedRecords = averagedRecords;
            this.historicalValues = historicalValues;
            this.total = total;
        }
        
        /**
         * Returns a list of the averages in the contained averaged record list.
         * @return
         */
        public TDoubleList getMetrics() {
            TDoubleList retVal = new TDoubleArrayList();
            for(Sample s : averagedRecords) {
                retVal.add(s.score);
            }
            
            return retVal;
        }
        
        /**
         * Returns a list of the sample values in the contained averaged record list.
         * @return
         */
        public TDoubleList getSamples() {
            TDoubleList retVal = new TDoubleArrayList();
            for(Sample s : averagedRecords) {
                retVal.add(s.value);
            }
            
            return retVal;
        }
        
        /**
         * Returns the size of the count of averaged records (i.e. {@link Sample}s)
         * @return
         */
        public int size() {
            return averagedRecords.size(); //let fail if null
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((averagedRecords == null) ? 0 : averagedRecords.hashCode());
            result = prime * result + ((historicalValues == null) ? 0 : historicalValues.hashCode());
            long temp;
            temp = Double.doubleToLongBits(total);
            result = prime * result + (int)(temp ^ (temp >>> 32));
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if(this == obj)
                return true;
            if(obj == null)
                return false;
            if(getClass() != obj.getClass())
                return false;
            AveragedAnomalyRecordList other = (AveragedAnomalyRecordList)obj;
            if(averagedRecords == null) {
                if(other.averagedRecords != null)
                    return false;
            } else if(!averagedRecords.equals(other.averagedRecords))
                return false;
            if(historicalValues == null) {
                if(other.historicalValues != null)
                    return false;
            } else if(!historicalValues.equals(other.historicalValues))
                return false;
            if(Double.doubleToLongBits(total) != Double.doubleToLongBits(other.total))
                return false;
            return true;
        }
    }
    
}
