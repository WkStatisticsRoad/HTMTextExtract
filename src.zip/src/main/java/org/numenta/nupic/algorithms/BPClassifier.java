package org.numenta.nupic.algorithms;

/*
*  下述代码构造单层BP神经网络进行分类预测
*  */

public class BPClassifier {
    private int inputSize;
    private int hiddenSize;
    private int outputSize;
    private double[][] inputHiddenWeights;
    private double[][] hiddenOutputWeights;
    private double[] hiddenThresholds;
    private double[] outputThresholds;
    private double learningRate;
    private double[] inputVector;
    private double[] hiddenOutput;
    private double[] output;
    private int[] targetOutputVector;
    int learnIteration;
    int recordNumMinusLearnIteration = -1;


    public BPClassifier(int inputSize, int hiddenSize, int outputSize, double learningRate) {

        this.inputSize = inputSize;
        this.hiddenSize = hiddenSize;
        this.outputSize = outputSize;
        this.learningRate = learningRate;
        this.inputHiddenWeights = new double[inputSize][hiddenSize];
        this.hiddenOutputWeights = new double[hiddenSize][outputSize];
        this.hiddenThresholds = new double[hiddenSize];
        this.outputThresholds = new double[outputSize];
        this.targetOutputVector = new int[outputSize];
        this.hiddenOutput = new double[hiddenSize];

        this.output = new double[outputSize];
        setHiddenSize(hiddenSize);
    }



    // 随机初始化权重和偏置值
    private void initializeWeightsAndThresholds() {
        for (int i = 0; i < inputSize; i++) {
            for (int j = 0; j < hiddenSize; j++) {
                inputHiddenWeights[i][j] = Math.random() * 0.2 - 0.1;
            }
        }
        for (int i = 0; i < hiddenSize; i++) {
            for (int j = 0; j < outputSize; j++) {
                hiddenOutputWeights[i][j] = Math.random() * 0.2 - 0.1;
            }
        }
        for (int i = 0; i < hiddenSize; i++) {
            hiddenThresholds[i] = Math.random() * 0.2 - 0.1;
        }
        for (int i = 0; i < outputSize; i++) {
            outputThresholds[i] = Math.random() * 0.2 - 0.1;
        }
    }

    public void setHiddenSize(int hiddenSize) {
        this.hiddenSize = hiddenSize;
        this.hiddenThresholds = new double[hiddenSize];
        this.inputHiddenWeights = new double[inputSize][hiddenSize];
        this.hiddenOutputWeights = new double[hiddenSize][outputSize];
        initializeWeightsAndThresholds();
    }

    public int[] compute(int recordNum, double[] inputVector, int[] targetOutputVector, boolean learn, boolean infer) {

        int[] predictOutput = null;
        if (recordNumMinusLearnIteration == -1) {
            recordNumMinusLearnIteration = recordNum - learnIteration;
        }

        // 更新学习迭代次数
        learnIteration = recordNum - recordNumMinusLearnIteration;
        System.out.printf("recordNum: %d\n", recordNum);
        System.out.printf("learnIteration: %d\n", learnIteration);

        this.targetOutputVector = targetOutputVector;

        // 动态更新 inputSize
//        if (inputSize != inputVector.length) {
//           inputSize = inputVector.length;
//        }

        // 不进行反向传播更新参数，只利用前向传播进行预测
        if (!learn && infer) {
            double[] output = forwardPropagation(inputVector);
            double[] doubleOutput = getFinalOutput(output);
            predictOutput = convertToIntArray(doubleOutput);
        }

        // 参数学习和预测同时进行
        if (learn && targetOutputVector != null && infer) {
            double[] output = forwardPropagation(inputVector);
            this.output = output;  // 将输出值赋给output成员变量
            train(inputVector, output);
            double[] doubleOutput = getFinalOutput(output);
            predictOutput = convertToIntArray(doubleOutput);
        }

        return predictOutput;
    }


    private void train(double[] inputVector, double[] output) {
        this.inputVector = inputVector;
        backwardPropagation(output);
    }


    // 前向传播
    private double[] forwardPropagation(double[] input) {

        double[] hiddenNet = new double[hiddenSize];
        double[] outputNet = new double[outputSize];

        // 计算输入-隐藏层的激活输出值
        for (int j = 0; j < hiddenSize; j++) {
            for (int i = 0; i < inputSize; i++) {
                hiddenNet[j] += input[i] * inputHiddenWeights[i][j];
            }
            hiddenNet[j] += hiddenThresholds[j];
            hiddenOutput[j] = sigmoid(hiddenNet[j]);
        }

        // 计算隐藏-输出层的激活输出值
        for (int j = 0; j < outputSize; j++) {
            for (int i = 0; i < hiddenSize; i++) {
                outputNet[j] += hiddenOutput[i] * hiddenOutputWeights[i][j];
            }
            outputNet[j] += outputThresholds[j];
            output[j] = sigmoid(outputNet[j]);
        }

        return output;
    }


    // 反向传播
    private void backwardPropagation(double[] output) {
        double[] outputError = new double[outputSize];
        double[] hiddenError = new double[hiddenSize];

        // 输出层误差
        for (int j = 0; j < outputSize; j++) {
            outputError[j] = (targetOutputVector[j] - output[j]) * sigmoidDerivative(output[j]);
        }

        // 隐藏层误差
        for (int j = 0; j < hiddenSize; j++) {
            for (int k = 0; k < outputSize; k++) {
                hiddenError[j] += outputError[k] * hiddenOutputWeights[j][k];
            }
            hiddenError[j] *= sigmoidDerivative(hiddenOutput[j]);
        }

        // 输入-隐藏层权重更新
        for (int i = 0; i < inputSize; i++) {
            for (int j = 0; j < hiddenSize; j++) {
                inputHiddenWeights[i][j] += learningRate * hiddenError[j] * inputVector[i];
            }
        }

        // 隐藏-输出层权重更新
        for (int i = 0; i < hiddenSize; i++) {
            for (int j = 0; j < outputSize; j++) {
                hiddenOutputWeights[i][j] += learningRate * outputError[j] * hiddenOutput[i];
            }
        }

        // 输入-隐藏层阈值更新
        for (int i = 0; i < hiddenSize; i++) {
            hiddenThresholds[i] += learningRate * hiddenError[i];
        }

        // // 隐藏-输出层阈值更新
        for (int i = 0; i < outputSize; i++) {
            outputThresholds[i] += learningRate * outputError[i];
        }
    }


    // sigmoid激活函数
    private double sigmoid(double x) {
        return 1 / (1 + Math.exp(-x));
    }


    // sigmoid求导函数
    private double sigmoidDerivative(double x) {
        return sigmoid(x) * (1 - sigmoid(x));
    }



    // 输出值大于0.9取1，小于0.1取0
    private double[] getFinalOutput(double[] output) {
        double[] finalOutput = new double[output.length];

        for (int i = 0; i < output.length; i++) {
            if (output[i] < 0.1) {
                finalOutput[i] = 0;
            } else if (output[i] > 0.9) {
                finalOutput[i] = 1;
            } else {
                finalOutput[i] = output[i];
            }
        }

        return finalOutput;
    }


    private int[] convertToIntArray(double[] output) {
        int[] intOutput = new int[output.length];

        for (int i = 0; i < output.length; i++) {
            intOutput[i] = (int) Math.round(output[i]);
        }

        return intOutput;
    }
}
