package org.numenta.nupic.research.sensorimotor;

/**
 * This class is a holding space for inclusion of NuPIC ports that are
 * still in the nupic.research repo but look like they might be more 
 * decided upon?
 * 
 * @author cogmission
 *
 */
public class TemporalPooler {

}
